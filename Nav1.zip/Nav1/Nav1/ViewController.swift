//
//  ViewController.swift
//  Nav1
//
//  Created by Dhiman on 2023-03-22.
//

import UIKit

class ViewController: UIViewController {


    @IBAction func fname(_ sender: UITextField, forEvent event: UIEvent) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

